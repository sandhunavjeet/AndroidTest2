
public class FizzBuzzWhizz {

}
